import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';


function Withdraw({ onSubmit }) {
  const [accountNumber, setAccountNumber] = useState('');
  const [amount, setAmount] = useState('');

  const handleWithdraw = (e) => {
    e.preventDefault();
    onSubmit({ accountNumber, amount });
    setAccountNumber('');
    setAmount('');
  };

  const handleCancel = () => {
    setAccountNumber('');
    setAmount('');
  };

  return (
    <div className="container">
      <h3>Withdraw</h3>
      <form onSubmit={handleWithdraw}>
        <div className="form-group">
          <label>Account Number</label>
          <input
            type="text"
            className="form-control"
            value={accountNumber}
            onChange={(e) => setAccountNumber(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Amount</label>
          <input
            type="number"
            className="form-control"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="mybtn btn btn-primary">
          Withdraw
        </button>
        <button type="button" className="mybtn btn btn-secondary ml-2" onClick={handleCancel}>
          Cancel
        </button>
      </form>
    </div>
  );
}

export default Withdraw;