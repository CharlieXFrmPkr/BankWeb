import React, { useState } from 'react';
import Deposit from './Deposit'; 
import Withdraw from './Withdraw'; 
import 'bootstrap/dist/css/bootstrap.min.css';

function Transaction() {
  const [view, setView] = useState('Deposit');
  const [transactions, setTransactions] = useState([]);
  const [balance, setBalance] = useState(0);
  const [eTransferEnabled, setETransferEnabled] = useState(false);
  const [eTransferForm, setETransferForm] = useState({
    from: '',
    to: '',
    amount: ''
  });

  const handleDepositSubmit = (data) => {
    const amount = parseFloat(data.amount);
    if (isNaN(amount) || amount <= 0) {
      alert('Invalid deposit amount');
      return;
    }
    
    const newBalance = balance + amount;
    setBalance(newBalance);
    setTransactions([
      ...transactions,
      { type: 'Deposit', amount, date: new Date().toLocaleDateString() }
    ]);
    setETransferEnabled(true); 
  };

  const handleWithdrawSubmit = (data) => {
    const amount = parseFloat(data.amount);
    if (isNaN(amount) || amount <= 0) {
      alert('Invalid withdrawal amount');
      return;
    }
    
    if (amount > balance) {
      alert('Insufficient balance');
      return;
    }
    
    const newBalance = balance - amount;
    setBalance(newBalance);
    setTransactions([
      ...transactions,
      { type: 'Withdrawal', amount, date: new Date().toLocaleDateString() }
    ]);
  };

  const handleETransferChange = (e) => {
    const { name, value } = e.target;
    setETransferForm({ ...eTransferForm, [name]: value });
  };

  const handleETransferSubmit = () => {
    const { from, to, amount } = eTransferForm;
    const transferAmount = parseFloat(amount);

    if (isNaN(transferAmount) || transferAmount <= 0) {
      alert('Invalid transfer amount');
      return;
    }

    if (transferAmount > balance) {
      alert('Insufficient balance for transfer');
      return;
    }

    const newBalance = balance - transferAmount;
    setBalance(newBalance);
    setTransactions([
      ...transactions,
      { type: 'E-Transfer', amount: transferAmount, from, to, date: new Date().toLocaleDateString() }
    ]);

    setETransferForm({
      from: '',
      to: '',
      amount: ''
    });
  };

  const buttonStyle = {
    backgroundColor: 'black',
    color: 'goldenrod',
    border: '1px solid goldenrod',
    marginRight: '10px',
    padding: '10px 20px',
    cursor: 'pointer',
    transition: 'background-color 0.3s ease, color 0.3s ease' 
  };

  const buttonStyleActive = {
    ...buttonStyle,
    backgroundColor: 'goldenrod',
    color: 'black',
    fontWeight: 'bold'
  };

  const inputStyle = {
    backgroundColor: '#333', 
    color: 'white', 
    border: '1px solid goldenrod', 
    padding: '10px'
  };

  return (
    <div className="container">
      <h2>Transaction</h2>
      <div className="mb-3">
        <button 
          style={view === 'Deposit' ? buttonStyleActive : buttonStyle}
          onClick={() => setView('Deposit')}
        >
          Deposit
        </button>
        <button 
          style={view === 'Withdraw' ? buttonStyleActive : buttonStyle}
          onClick={() => setView('Withdraw')}
        >
          Withdraw
        </button>
        <button 
          style={view === 'E-Transfer' ? buttonStyleActive : buttonStyle}
          onClick={() => setView('E-Transfer')}
          disabled={!eTransferEnabled}
        >
          E-Transfer
        </button>
      </div>

      {view === 'Deposit' && <Deposit onSubmit={handleDepositSubmit} />}
      {view === 'Withdraw' && <Withdraw onSubmit={handleWithdrawSubmit} />}
      {view === 'E-Transfer' && (
        <div className="mt-4">
          <h3>E-Transfer</h3>
          <div className="form-group">
            <label htmlFor="from">Send From</label>
            <input
              type="text"
              id="from"
              name="from"
              className="form-control"
              style={inputStyle}
              value={eTransferForm.from}
              onChange={handleETransferChange}
              placeholder="Enter account number"
            />
          </div>
          <div className="form-group">
            <label htmlFor="to">Send To</label>
            <input
              type="text"
              id="to"
              name="to"
              className="form-control"
              style={inputStyle}
              value={eTransferForm.to}
              onChange={handleETransferChange}
              placeholder="Enter account number"
            />
          </div>
          <div className="form-group">
            <label htmlFor="amount">Amount</label>
            <input
              type="number"
              id="amount"
              name="amount"
              className="form-control"
              style={inputStyle}
              value={eTransferForm.amount}
              onChange={handleETransferChange}
              placeholder="Enter amount"
            />
          </div>
          <button 
            className="btn mt-3" 
            style={buttonStyle}
            onClick={handleETransferSubmit}
          >
            E-Transfer
          </button>
        </div>
      )}

      <h3 className="mt-4">Transaction History</h3>
      <table className="table table-striped">
        <thead>
          <tr>
            <th>Date</th>
            <th>Type</th>
            <th>Amount</th>
            <th>From</th>
            <th>To</th>
          </tr>
        </thead>
        <tbody>
          {transactions.map((transaction, index) => (
            <tr key={index}>
              <td>{transaction.date}</td>
              <td>{transaction.type}</td>
              <td>${Number(transaction.amount).toFixed(2)}</td>
              <td>{transaction.from || '-'}</td>
              <td>{transaction.to || '-'}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="mt-3">
        <h4>Current Balance: ${balance.toFixed(2)}</h4>
      </div>
    </div>
  );
}

export default Transaction;
